package com.classselector;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

public class RaceLookup {
    /** Raça do jogador (funciona no servidor e no cliente). */
    public static RaceDef of(Player p) {
        if (p.level().isClientSide) return ClientState.races.get(ClientState.myRace);
        if (p instanceof ServerPlayer sp) {
            String id = sp.getPersistentData().getString(ClassSelectorMod.KEY_RACE);
            return id.isEmpty() ? null : RaceData.get(sp.server).races.get(id);
        }
        return null;
    }
}
