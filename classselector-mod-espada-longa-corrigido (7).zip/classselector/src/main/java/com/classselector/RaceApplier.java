package com.classselector;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.registries.ForgeRegistries;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Aplica os bônus da raça como modificadores PERMANENTES de atributo
 * (não são efeitos de poção: não aparecem no HUD, não somem com leite/morte).
 */
public class RaceApplier {
    private static UUID uuid(String key) {
        return UUID.nameUUIDFromBytes(("classselector:race:" + key).getBytes(StandardCharsets.UTF_8));
    }

    public static void refresh(ServerPlayer p) {
        String rid = p.getPersistentData().getString(ClassSelectorMod.KEY_RACE);
        RaceDef r = rid.isEmpty() ? null : RaceData.get(p.server).races.get(rid);

        set(p, Attributes.ARMOR, "armor", r == null ? 0 : r.armor, AttributeModifier.Operation.ADDITION);
        set(p, Attributes.ATTACK_DAMAGE, "damage", r == null ? 0 : r.damage, AttributeModifier.Operation.ADDITION);
        set(p, Attributes.MOVEMENT_SPEED, "speed", r == null ? 0 : r.speedPct / 100.0, AttributeModifier.Operation.MULTIPLY_BASE);

        // Atributo do Iron's Spells, buscado pelo id para não depender dele na compilação
        Attribute mana = ForgeRegistries.ATTRIBUTES.getValue(new ResourceLocation("irons_spellbooks", "max_mana"));
        if (mana != null) set(p, mana, "mana", r == null ? 0 : r.mana, AttributeModifier.Operation.ADDITION);
    }

    private static void set(ServerPlayer p, Attribute a, String key, double value, AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(a);
        if (inst == null) return;
        UUID id = uuid(key);
        inst.removeModifier(id);
        if (value != 0) inst.addPermanentModifier(new AttributeModifier(id, "classselector_" + key, value, op));
    }
}
