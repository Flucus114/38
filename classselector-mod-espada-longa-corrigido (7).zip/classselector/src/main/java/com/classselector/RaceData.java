package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.LinkedHashMap;
import java.util.Map;

public class RaceData extends SavedData {
    public final Map<String, RaceDef> races = new LinkedHashMap<>();

    public static RaceData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(RaceData::load, RaceData::createDefault, "classselector_races");
    }

    private static RaceDef make(String id, String name, String desc, String icon) {
        RaceDef r = new RaceDef();
        r.id = id; r.name = name; r.description = desc; r.icon = icon;
        return r;
    }

    private static RaceData createDefault() {
        RaceData d = new RaceData();

        RaceDef h = make("humano", "Humano", "Versáteis e adaptáveis, aprendem rápido e tiram mais de qualquer ofício.", "minecraft:emerald");
        h.miningPct = 5; h.speedPct = 3; h.enchant = 2;
        d.races.put(h.id, h);

        RaceDef e = make("elfo", "Elfo", "Ágeis e ligados à magia, mas de constituição frágil.", "minecraft:amethyst_shard");
        e.mana = 50; e.speedPct = 10; e.armor = -1;
        d.races.put(e.id, e);

        RaceDef a = make("anao", "Anão", "Resistentes e mestres da mineração, porém lentos.", "minecraft:iron_pickaxe");
        a.armor = 3; a.miningPct = 25; a.speedPct = -5;
        d.races.put(a.id, a);

        RaceDef o = make("orc", "Orc", "Brutos e fortes, com pouca afinidade com a magia.", "minecraft:iron_axe");
        o.damage = 2; o.armor = 1; o.mana = -20;
        d.races.put(o.id, o);

        d.setDirty();
        return d;
    }

    public static RaceData load(CompoundTag tag) {
        RaceData d = new RaceData();
        for (Tag t : tag.getList("races", Tag.TAG_COMPOUND)) {
            RaceDef r = RaceDef.load((CompoundTag) t);
            if (!r.id.isEmpty()) d.races.put(r.id, r);
        }
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag l = new ListTag();
        for (RaceDef r : races.values()) l.add(r.save());
        tag.put("races", l);
        return tag;
    }
}
