package com.classselector;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.forgespi.language.IModInfo;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * /restrict block|unblock|list  -> itens/mods bloqueados por classe
 * /lootpurge add|remove|list|boss -> itens removidos de baús e drops de bosses
 */
@Mod.EventBusSubscriber(modid = ClassSelectorMod.MODID)
public class RestrictCommands {
    private interface RuleAction {
        int run(CommandContext<CommandSourceStack> c, String rule) throws CommandSyntaxException;
    }

    private static RequiredArgumentBuilder<CommandSourceStack, String> classArg() {
        return Commands.argument("class", StringArgumentType.word()).suggests((c, b) ->
                SharedSuggestionProvider.suggest(ClassData.get(c.getSource().getServer()).classes.keySet(), b));
    }

    private static RequiredArgumentBuilder<CommandSourceStack, ResourceLocation> itemArg() {
        return Commands.argument("item", ResourceLocationArgument.id()).suggests((c, b) ->
                SharedSuggestionProvider.suggestResource(ForgeRegistries.ITEMS.getKeys(), b));
    }

    private static RequiredArgumentBuilder<CommandSourceStack, String> modArg() {
        return Commands.argument("mod", StringArgumentType.word()).suggests((c, b) ->
                SharedSuggestionProvider.suggest(ModList.get().getMods().stream().map(IModInfo::getModId), b));
    }

    /** Anexa os ramos "item <id>", "mod <modid>" e "hand" (item na mão) ao nó dado. */
    private static <T extends ArgumentBuilder<CommandSourceStack, T>> T attach(T parent, RuleAction a) {
        parent.then(Commands.literal("item").then(itemArg().executes(c -> {
            ResourceLocation rl = ResourceLocationArgument.getId(c, "item");
            if (!ForgeRegistries.ITEMS.containsKey(rl)) {
                c.getSource().sendFailure(Component.literal("Item não encontrado: " + rl));
                return 0;
            }
            return a.run(c, rl.toString());
        })));
        parent.then(Commands.literal("mod").then(modArg().executes(c -> {
            String mod = StringArgumentType.getString(c, "mod").toLowerCase();
            if (!ModList.get().isLoaded(mod)) {
                c.getSource().sendFailure(Component.literal("Mod não encontrado: " + mod));
                return 0;
            }
            return a.run(c, "@" + mod);
        })));
        parent.then(Commands.literal("hand").executes(c -> {
            ItemStack held = c.getSource().getPlayerOrException().getMainHandItem();
            if (held.isEmpty()) {
                c.getSource().sendFailure(Component.literal("Segure um item na mão principal."));
                return 0;
            }
            return a.run(c, String.valueOf(ForgeRegistries.ITEMS.getKey(held.getItem())));
        }));
        return parent;
    }

    private static String pretty(String rule) {
        return rule.startsWith("@") ? "todos os itens do mod " + rule.substring(1) : rule;
    }

    private static boolean classExists(CommandContext<CommandSourceStack> c, String cls) {
        if (ClassData.get(c.getSource().getServer()).classes.containsKey(cls)) return true;
        c.getSource().sendFailure(Component.literal("Classe não encontrada: " + cls
                + ". Disponíveis: " + String.join(", ", ClassData.get(c.getSource().getServer()).classes.keySet())));
        return false;
    }

    private static void listRules(CommandContext<CommandSourceStack> c, String title, Set<String> rules) {
        if (rules == null || rules.isEmpty()) {
            c.getSource().sendSuccess(() -> Component.literal(title + ": (vazio)"), false);
            return;
        }
        StringBuilder sb = new StringBuilder(title + " (" + rules.size() + "):");
        for (String r : rules) sb.append("\n - ").append(pretty(r));
        c.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();

        // ---------- /restrict ----------
        LiteralArgumentBuilder<CommandSourceStack> restrict = Commands.literal("restrict")
                .requires(s -> s.hasPermission(2));

        restrict.then(Commands.literal("block").then(attach(classArg(), (c, rule) -> {
            String cls = StringArgumentType.getString(c, "class");
            if (!classExists(c, cls)) return 0;
            MinecraftServer server = c.getSource().getServer();
            RestrictionData rd = RestrictionData.get(server);
            boolean added = rd.blocked.computeIfAbsent(cls, k -> new LinkedHashSet<>()).add(rule);
            rd.setDirty();
            RestrictManager.syncAll(server);
            c.getSource().sendSuccess(() -> Component.literal(added
                    ? "Bloqueado para a classe " + cls + ": " + pretty(rule)
                    : "Já estava bloqueado para " + cls + ": " + pretty(rule)), true);
            return 1;
        })));

        restrict.then(Commands.literal("unblock").then(attach(classArg().then(Commands.literal("all").executes(c -> {
            String cls = StringArgumentType.getString(c, "class");
            if (!classExists(c, cls)) return 0;
            MinecraftServer server = c.getSource().getServer();
            RestrictionData rd = RestrictionData.get(server);
            rd.blocked.remove(cls);
            rd.setDirty();
            RestrictManager.syncAll(server);
            c.getSource().sendSuccess(() -> Component.literal("Todos os bloqueios da classe " + cls + " foram removidos."), true);
            return 1;
        })), (c, rule) -> {
            String cls = StringArgumentType.getString(c, "class");
            if (!classExists(c, cls)) return 0;
            MinecraftServer server = c.getSource().getServer();
            RestrictionData rd = RestrictionData.get(server);
            Set<String> set = rd.blocked.get(cls);
            boolean removed = set != null && set.remove(rule);
            if (set != null && set.isEmpty()) rd.blocked.remove(cls);
            rd.setDirty();
            RestrictManager.syncAll(server);
            c.getSource().sendSuccess(() -> Component.literal(removed
                    ? "Desbloqueado para a classe " + cls + ": " + pretty(rule)
                    : "Não estava bloqueado para " + cls + ": " + pretty(rule)), true);
            return 1;
        })));

        restrict.then(Commands.literal("list")
                .executes(c -> {
                    RestrictionData rd = RestrictionData.get(c.getSource().getServer());
                    if (rd.blocked.isEmpty()) {
                        c.getSource().sendSuccess(() -> Component.literal("Nenhuma restrição configurada."), false);
                        return 1;
                    }
                    for (var en : rd.blocked.entrySet()) listRules(c, "Classe " + en.getKey(), en.getValue());
                    return 1;
                })
                .then(classArg().executes(c -> {
                    String cls = StringArgumentType.getString(c, "class");
                    if (!classExists(c, cls)) return 0;
                    listRules(c, "Classe " + cls, RestrictionData.get(c.getSource().getServer()).blocked.get(cls));
                    return 1;
                })));

        d.register(restrict);

        // ---------- /lootpurge ----------
        LiteralArgumentBuilder<CommandSourceStack> purge = Commands.literal("lootpurge")
                .requires(s -> s.hasPermission(2));

        purge.then(attach(Commands.literal("add"), (c, rule) -> {
            RestrictionData rd = RestrictionData.get(c.getSource().getServer());
            boolean added = rd.purge.add(rule);
            rd.setDirty();
            c.getSource().sendSuccess(() -> Component.literal(added
                    ? "Será removido de baús e drops de bosses: " + pretty(rule)
                    : "Já estava na lista: " + pretty(rule)), true);
            return 1;
        }));

        purge.then(attach(Commands.literal("remove").then(Commands.literal("all").executes(c -> {
            RestrictionData rd = RestrictionData.get(c.getSource().getServer());
            rd.purge.clear();
            rd.setDirty();
            c.getSource().sendSuccess(() -> Component.literal("Lista de purge limpa."), true);
            return 1;
        })), (c, rule) -> {
            RestrictionData rd = RestrictionData.get(c.getSource().getServer());
            boolean removed = rd.purge.remove(rule);
            rd.setDirty();
            c.getSource().sendSuccess(() -> Component.literal(removed
                    ? "Removido da lista de purge: " + pretty(rule)
                    : "Não estava na lista: " + pretty(rule)), true);
            return 1;
        }));

        purge.then(Commands.literal("list").executes(c -> {
            listRules(c, "Purge de loot", RestrictionData.get(c.getSource().getServer()).purge);
            return 1;
        }));

        // bosses extras (além dos que já têm a tag forge:bosses, dragão, wither e guardião ancião)
        purge.then(Commands.literal("boss")
                .then(Commands.literal("add").then(entityArg().executes(c -> {
                    ResourceLocation rl = ResourceLocationArgument.getId(c, "entity");
                    if (!ForgeRegistries.ENTITY_TYPES.containsKey(rl)) {
                        c.getSource().sendFailure(Component.literal("Entidade não encontrada: " + rl));
                        return 0;
                    }
                    RestrictionData rd = RestrictionData.get(c.getSource().getServer());
                    boolean added = rd.bosses.add(rl.toString());
                    rd.setDirty();
                    c.getSource().sendSuccess(() -> Component.literal(added
                            ? "Agora tratado como boss: " + rl : "Já estava na lista de bosses: " + rl), true);
                    return 1;
                })))
                .then(Commands.literal("remove").then(entityArg().executes(c -> {
                    ResourceLocation rl = ResourceLocationArgument.getId(c, "entity");
                    RestrictionData rd = RestrictionData.get(c.getSource().getServer());
                    boolean removed = rd.bosses.remove(rl.toString());
                    rd.setDirty();
                    c.getSource().sendSuccess(() -> Component.literal(removed
                            ? "Removido da lista de bosses: " + rl : "Não estava na lista de bosses: " + rl), true);
                    return 1;
                })))
                .then(Commands.literal("list").executes(c -> {
                    listRules(c, "Bosses extras", RestrictionData.get(c.getSource().getServer()).bosses);
                    return 1;
                })));

        d.register(purge);
    }

    private static RequiredArgumentBuilder<CommandSourceStack, ResourceLocation> entityArg() {
        return Commands.argument("entity", ResourceLocationArgument.id()).suggests((c, b) ->
                SharedSuggestionProvider.suggestResource(ForgeRegistries.ENTITY_TYPES.getKeys(), b));
    }
}
