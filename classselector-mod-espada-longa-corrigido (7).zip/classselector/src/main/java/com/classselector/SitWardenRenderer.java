package com.classselector;

import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.WardenRenderer;

/** Renderer do Warden idêntico ao vanilla, mas usando o modelo que sabe sentar. */
public class SitWardenRenderer extends WardenRenderer {
    public SitWardenRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new SitWardenModel(ctx.bakeLayer(ModelLayers.WARDEN));
    }
}
