package com.classselector;

import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEnchantments {
    public static final DeferredRegister<Enchantment> ENCHANTMENTS =
            DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, ClassSelectorMod.MODID);

    /** Encantamento de arco: raios onde a flecha cair. Ex.: /enchant @s classselector:thunder_call 3 */
    public static final RegistryObject<Enchantment> THUNDER_CALL =
            ENCHANTMENTS.register("thunder_call", ThunderCallEnchantment::new);
}
