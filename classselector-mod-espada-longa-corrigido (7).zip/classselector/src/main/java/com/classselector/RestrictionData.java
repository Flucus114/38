package com.classselector;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.monster.ElderGuardian;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * Restrições por classe + lista de purge de loot.
 * Regra: "modid:item" = um item; "@modid" = todos os itens de um mod.
 */
public class RestrictionData extends SavedData {
    public final Map<String, Set<String>> blocked = new LinkedHashMap<>();
    /** Itens/mods removidos do loot de baús e de bosses. */
    public final Set<String> purge = new LinkedHashSet<>();
    /** Tipos de entidade extras tratados como boss (além da tag forge:bosses). */
    public final Set<String> bosses = new LinkedHashSet<>();

    public static RestrictionData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(RestrictionData::load, RestrictionData::new, "classselector_restrictions");
    }

    public static boolean matches(Set<String> rules, ResourceLocation id) {
        if (id == null || rules.isEmpty()) return false;
        return rules.contains(id.toString()) || rules.contains("@" + id.getNamespace());
    }

    public static boolean matches(Set<String> rules, ItemStack s) {
        if (s.isEmpty() || rules.isEmpty()) return false;
        return matches(rules, ForgeRegistries.ITEMS.getKey(s.getItem()));
    }

    public boolean isPurged(ItemStack s) {
        return matches(purge, s);
    }

    public boolean isBoss(Entity e) {
        if (e == null) return false;
        EntityType<?> t = e.getType();
        if (t.is(Tags.EntityTypes.BOSSES)) return true;
        if (e instanceof EnderDragon || e instanceof WitherBoss || e instanceof ElderGuardian) return true;
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(t);
        return id != null && bosses.contains(id.toString());
    }

    public static RestrictionData load(CompoundTag tag) {
        RestrictionData d = new RestrictionData();
        for (Tag t : tag.getList("blocked", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) t;
            String cls = c.getString("class");
            if (cls.isEmpty()) continue;
            Set<String> set = new LinkedHashSet<>();
            for (Tag r : c.getList("rules", Tag.TAG_STRING)) set.add(r.getAsString());
            d.blocked.put(cls, set);
        }
        for (Tag t : tag.getList("purge", Tag.TAG_STRING)) d.purge.add(t.getAsString());
        for (Tag t : tag.getList("bosses", Tag.TAG_STRING)) d.bosses.add(t.getAsString());
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag bl = new ListTag();
        for (Map.Entry<String, Set<String>> en : blocked.entrySet()) {
            if (en.getValue().isEmpty()) continue;
            CompoundTag c = new CompoundTag();
            c.putString("class", en.getKey());
            ListTag rl = new ListTag();
            for (String s : en.getValue()) rl.add(StringTag.valueOf(s));
            c.put("rules", rl);
            bl.add(c);
        }
        tag.put("blocked", bl);
        ListTag pl = new ListTag();
        for (String s : purge) pl.add(StringTag.valueOf(s));
        tag.put("purge", pl);
        ListTag bo = new ListTag();
        for (String s : bosses) bo.add(StringTag.valueOf(s));
        tag.put("bosses", bo);
        return tag;
    }
}
