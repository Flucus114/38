package com.classselector;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Tela de quests com a mesma aparência da tela de conquistas do Minecraft. */
public class QuestScreen extends Screen {
    private static final ResourceLocation WINDOW = new ResourceLocation("textures/gui/advancements/window.png");
    private static final ResourceLocation TABS = new ResourceLocation("textures/gui/advancements/tabs.png");
    private static final ResourceLocation WIDGETS = new ResourceLocation("textures/gui/advancements/widgets.png");
    private static final ResourceLocation BG = new ResourceLocation("textures/gui/advancements/backgrounds/stone.png");

    private static final int WW = 252, WH = 140, IX = 9, IY = 18, IW = 234, IH = 113, MAX_TABS = 7;
    private static final int COL_W = 40, ROW_H = 32;

    private static String lastTab = null;
    private double sx, sy;
    private int tabOffset, wx, wy;

    public QuestScreen() { super(Component.literal("Missões")); }

    @Override
    protected void init() {
        wx = (width - WW) / 2;
        wy = (height - WH) / 2;
        if (ClientState.op) {
            int by = wy + WH + 6;
            addRenderableWidget(Button.builder(Component.literal("+ Aba"),
                    b -> minecraft.setScreen(new QuestTabEditScreen(this, null)))
                    .bounds(wx, by, 58, 20).build());
            addRenderableWidget(Button.builder(Component.literal("Editar aba"), b -> {
                QuestTabDef t = currentTab();
                if (t != null) minecraft.setScreen(new QuestTabEditScreen(this, t));
            }).bounds(wx + 62, by, 70, 20).build());
            addRenderableWidget(Button.builder(Component.literal("+ Quest"), b -> {
                QuestTabDef t = currentTab();
                if (t != null) minecraft.setScreen(new QuestEditScreen(this, t.id, null));
            }).bounds(wx + 136, by, 58, 20).build());
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }

    private QuestTabDef currentTab() {
        List<QuestTabDef> tl = QuestClientState.tabs;
        if (tl.isEmpty()) return null;
        for (QuestTabDef t : tl) if (t.id.equals(lastTab)) return t;
        lastTab = tl.get(0).id;
        return tl.get(0);
    }

    // ---------- layout da árvore ----------
    private int place(QuestDef q, int col, int row, Map<String, List<QuestDef>> kids, Map<String, int[]> pos) {
        if (pos.containsKey(q.id)) return row;
        pos.put(q.id, new int[]{col, row});
        int next = row;
        boolean first = true;
        for (QuestDef c : kids.getOrDefault(q.id, List.of())) {
            if (pos.containsKey(c.id)) continue;
            next = place(c, col + 1, first ? row : next, kids, pos);
            first = false;
        }
        return Math.max(next, row + 1);
    }

    private Map<String, int[]> layout(String tab) {
        List<QuestDef> list = new ArrayList<>();
        Set<String> ids = new HashSet<>();
        for (QuestDef q : QuestClientState.quests.values()) {
            if (q.tab.equals(tab)) { list.add(q); ids.add(q.id); }
        }
        Map<String, List<QuestDef>> kids = new HashMap<>();
        List<QuestDef> roots = new ArrayList<>();
        for (QuestDef q : list) {
            if (q.parent.isEmpty() || !ids.contains(q.parent) || q.parent.equals(q.id)) roots.add(q);
            else kids.computeIfAbsent(q.parent, k -> new ArrayList<>()).add(q);
        }
        Map<String, int[]> pos = new LinkedHashMap<>();
        int row = 0;
        for (QuestDef r : roots) row = place(r, 0, row, kids, pos);
        for (QuestDef q : list) if (!pos.containsKey(q.id)) row = place(q, 0, row, kids, pos);
        return pos;
    }

    private int nodeX(int col) { return wx + IX + 10 + (int) sx + col * COL_W; }
    private int nodeY(int row) { return wy + IY + 8 + (int) sy + row * ROW_H; }

    private boolean inTree(double mx, double my) {
        return mx >= wx + IX && mx < wx + IX + IW && my >= wy + IY && my < wy + IY + IH;
    }

    private QuestDef hitQuest(double mx, double my) {
        QuestTabDef tab = currentTab();
        if (tab == null || !inTree(mx, my)) return null;
        for (Map.Entry<String, int[]> e : layout(tab.id).entrySet()) {
            int nx = nodeX(e.getValue()[0]), ny = nodeY(e.getValue()[1]);
            if (mx >= nx && mx < nx + 26 && my >= ny && my < ny + 26) return QuestClientState.quests.get(e.getKey());
        }
        return null;
    }

    private void elbow(GuiGraphics g, int x1, int y1, int x2, int y2, int color) {
        int mid = x1 + (x2 - x1) / 2;
        for (int d = -1; d <= 1; d++) {
            g.hLine(x1, mid, y1 + d, 0xFF000000);
            g.vLine(mid + d, y1, y2, 0xFF000000);
            g.hLine(mid, x2, y2 + d, 0xFF000000);
        }
        g.hLine(x1, mid, y1, color);
        g.vLine(mid, y1, y2, color);
        g.hLine(mid, x2, y2, color);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        QuestTabDef tab = currentTab();
        QuestDef hover = null;

        // ---- interior (árvore) ----
        g.enableScissor(wx + IX, wy + IY, wx + IX + IW, wy + IY + IH);
        int ox = Math.floorMod((int) sx, 16), oy = Math.floorMod((int) sy, 16);
        for (int gx = wx + IX - 16 + ox; gx < wx + IX + IW; gx += 16)
            for (int gy = wy + IY - 16 + oy; gy < wy + IY + IH; gy += 16)
                g.blit(BG, gx, gy, 0f, 0f, 16, 16, 16, 16);

        if (tab != null) {
            Map<String, int[]> pos = layout(tab.id);
            int maxCol = 0, maxRow = 0;
            for (int[] p : pos.values()) { maxCol = Math.max(maxCol, p[0]); maxRow = Math.max(maxRow, p[1]); }
            sx = Mth.clamp(sx, Math.min(0, IW - (maxCol * COL_W + 60)), 0);
            sy = Mth.clamp(sy, Math.min(0, IH - (maxRow * ROW_H + 44)), 0);

            for (Map.Entry<String, int[]> e : pos.entrySet()) {
                QuestDef q = QuestClientState.quests.get(e.getKey());
                int[] pp = pos.get(q.parent);
                if (pp == null) continue;
                boolean ok = QuestClientState.done.contains(q.parent);
                elbow(g, nodeX(pp[0]) + 26, nodeY(pp[1]) + 13, nodeX(e.getValue()[0]), nodeY(e.getValue()[1]) + 13,
                        ok ? 0xFFFFFFFF : 0xFF909090);
            }
            for (Map.Entry<String, int[]> e : pos.entrySet()) {
                QuestDef q = QuestClientState.quests.get(e.getKey());
                int nx = nodeX(e.getValue()[0]), ny = nodeY(e.getValue()[1]);
                boolean done = QuestClientState.done.contains(q.id);
                boolean open = QuestClientState.unlocked(q);
                g.blit(WIDGETS, nx, ny, 0, 128 + (done ? 0 : 26), 26, 26);
                g.renderItem(q.iconStack(), nx + 5, ny + 5);
                if (!done && !open) g.fill(nx + 3, ny + 3, nx + 23, ny + 23, 0x99000000);
                if (inTree(mx, my) && mx >= nx && mx < nx + 26 && my >= ny && my < ny + 26) hover = q;
            }
            if (pos.isEmpty()) {
                g.drawCenteredString(font, "Nenhuma quest nesta aba", wx + WW / 2, wy + IY + IH / 2 - 4, 0xFFAAAAAA);
            }
        } else {
            g.drawCenteredString(font, "Nenhuma aba criada", wx + WW / 2, wy + IY + IH / 2 - 4, 0xFFAAAAAA);
        }
        g.disableScissor();

        // ---- moldura e abas ----
        g.blit(WINDOW, wx, wy, 0, 0, WW, WH);
        g.drawString(font, "Missões", wx + 8, wy + 6, 0x404040, false);

        List<QuestTabDef> tl = QuestClientState.tabs;
        tabOffset = Mth.clamp(tabOffset, 0, Math.max(0, tl.size() - MAX_TABS));
        int shown = Math.min(MAX_TABS, tl.size() - tabOffset);
        QuestTabDef hoverTab = null;
        for (int i = 0; i < shown; i++) {
            QuestTabDef t = tl.get(tabOffset + i);
            int tx = wx + 32 * i, ty = wy - 28;
            boolean sel = tab != null && t.id.equals(tab.id);
            g.blit(TABS, tx, ty, i > 0 ? 28 : 0, sel ? 32 : 0, 28, 32);
            g.renderItem(t.iconStack(), tx + 6, ty + 9);
            if (mx >= tx && mx < tx + 28 && my >= ty && my < ty + 32) hoverTab = t;
        }

        super.render(g, mx, my, pt);

        // ---- tooltips ----
        if (hover != null) renderQuestTooltip(g, hover, mx, my);
        else if (hoverTab != null) {
            List<FormattedCharSequence> tt = new ArrayList<>();
            tt.add(Component.literal(hoverTab.name).getVisualOrderText());
            if (!hoverTab.classId.isEmpty()) {
                String cn = hoverTab.classId;
                for (ClassDef c : ClientState.classes) if (c.id.equals(hoverTab.classId)) cn = c.name;
                tt.add(Component.literal("Exclusiva: " + cn).withStyle(ChatFormatting.AQUA).getVisualOrderText());
            }
            g.renderTooltip(font, tt, mx, my);
        }

        if (ClientState.op) {
            g.drawString(font, "Botão direito numa quest = editar", wx + 200 > width ? wx : wx + 200 - 6 + 0,
                    wy + WH + 12, 0xFF888888, false);
        }
    }

    private void renderQuestTooltip(GuiGraphics g, QuestDef q, int mx, int my) {
        boolean done = QuestClientState.done.contains(q.id);
        boolean open = QuestClientState.unlocked(q);
        List<FormattedCharSequence> tip = new ArrayList<>();
        tip.add(Component.literal(q.name).withStyle(ChatFormatting.GOLD).getVisualOrderText());
        if (!q.description.isEmpty())
            tip.addAll(font.split(Component.literal(q.description).withStyle(ChatFormatting.GRAY), 170));
        tip.addAll(font.split(Component.literal(q.objective()).withStyle(ChatFormatting.WHITE), 170));
        if (done) {
            tip.add(Component.literal("Concluída").withStyle(ChatFormatting.GREEN).getVisualOrderText());
        } else if (open) {
            int v = QuestClientState.progress.getOrDefault(q.id, 0);
            tip.add(Component.literal("Progresso: " + v + "/" + q.amount).withStyle(ChatFormatting.YELLOW).getVisualOrderText());
        } else {
            QuestDef par = QuestClientState.quests.get(q.parent);
            String pn = par == null ? q.parent : par.name;
            tip.addAll(font.split(Component.literal("Bloqueada: conclua \"" + pn + "\"").withStyle(ChatFormatting.RED), 170));
        }
        if (!q.rewards.isEmpty() || q.xp > 0) {
            tip.add(Component.literal("Recompensa:").withStyle(ChatFormatting.AQUA).getVisualOrderText());
            int n = 0;
            for (ItemStack s : q.rewards) {
                if (n++ >= 6) { tip.add(Component.literal("  ...").getVisualOrderText()); break; }
                tip.add(Component.literal("  " + s.getCount() + "x " + s.getHoverName().getString()).getVisualOrderText());
            }
            if (q.xp > 0) tip.add(Component.literal("  +" + q.xp + " níveis de XP").getVisualOrderText());
        }
        g.renderTooltip(font, tip, mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        List<QuestTabDef> tl = QuestClientState.tabs;
        int shown = Math.min(MAX_TABS, tl.size() - tabOffset);
        if (button == 0) {
            for (int i = 0; i < shown; i++) {
                int tx = wx + 32 * i, ty = wy - 28;
                if (mx >= tx && mx < tx + 28 && my >= ty && my < ty + 32) {
                    lastTab = tl.get(tabOffset + i).id;
                    sx = 0;
                    sy = 0;
                    return true;
                }
            }
        }
        if (button == 1 && ClientState.op) {
            QuestDef q = hitQuest(mx, my);
            QuestTabDef tab = currentTab();
            if (q != null && tab != null) {
                minecraft.setScreen(new QuestEditScreen(this, tab.id, q));
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && inTree(mx, my)) {
            sx += dx;
            sy += dy;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (my >= wy - 28 && my < wy + 4) {
            tabOffset -= (int) Math.signum(delta);
            return true;
        }
        return super.mouseScrolled(mx, my, delta);
    }
}
