package com.classselector;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundStopSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Hyper Arco de Sculk. Estende BowItem só para continuar encantável como arco (Chamado do Trovão etc.);
 * todo o comportamento é próprio e NÃO consome flechas.
 *
 * Fluxo: botão direito segura = carrega (BowConfig.CHARGE_TICKS); soltar dispara o Raio Supersônico
 * (cálculo de linha, colisão com blocos e dano 100% no servidor). Recarga em BowConfig.COOLDOWN_TICKS.
 * O feixe visual é feito com partículas enviadas pelo servidor (vanilla), com vida curta.
 */
public class HyperSculkBowItem extends BowItem {
    /** Carga mínima (ticks) para disparar; soltar antes cancela sem gastar nada. */
    private static final int MIN_TICKS = 6;
    private static final DustParticleOptions CYAN = new DustParticleOptions(new Vector3f(0.14F, 0.91F, 1.0F), 0.8F);
    private static final DustParticleOptions DEEP = new DustParticleOptions(new Vector3f(0.03F, 0.30F, 0.60F), 0.7F);

    public HyperSculkBowItem() {
        super(new Item.Properties().durability(900).rarity(Rarity.EPIC));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);
        player.startUsingItem(hand);
        if (!level.isClientSide) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.WARDEN_SONIC_CHARGE, SoundSource.PLAYERS, 0.7F, 1.0F);
        }
        return InteractionResultHolder.consume(stack);
    }

    /** Efeitos de carga (somente servidor): fragmentos de sculk convergindo e pulso na carga máxima. */
    @Override
    public void onUseTick(Level level, LivingEntity user, ItemStack stack, int remaining) {
        if (!(level instanceof ServerLevel sl)) return;
        int ticks = this.getUseDuration(stack) - remaining;
        int max = BowConfig.CHARGE_TICKS.get();
        Vec3 hand = user.getEyePosition().add(user.getLookAngle().scale(0.9D)).add(0.0D, -0.25D, 0.0D);
        if (ticks < max) {
            if (ticks % 3 == 0) {
                int n = 1 + ticks * 3 / max;
                sl.sendParticles(ParticleTypes.SCULK_SOUL, hand.x, hand.y, hand.z, n, 0.45D, 0.45D, 0.45D, 0.01D);
            }
        } else if (ticks == max) { // pulso ao chegar na carga máxima
            sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, hand.x, hand.y, hand.z, 14, 0.3D, 0.3D, 0.3D, 0.25D);
            level.playSound(null, user.getX(), user.getY(), user.getZ(),
                    SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.0F, 1.4F);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity user, int timeLeft) {
        if (!(user instanceof Player player) || level.isClientSide || !(level instanceof ServerLevel sl)) return;
        int ticks = this.getUseDuration(stack) - timeLeft;
        if (ticks < MIN_TICKS) { // carga cancelada: nada é gasto
            stopChargeSound(player);
            return;
        }
        float frac = Mth.clamp(ticks / (float) BowConfig.CHARGE_TICKS.get(), 0.0F, 1.0F);
        float damage = (float) Mth.lerp(frac, BowConfig.MIN_DAMAGE.get(), BowConfig.MAX_DAMAGE.get());

        stopChargeSound(player);
        Vec3 impact = fire(sl, player, damage);

        int thunder = EnchantmentHelper.getTagEnchantmentLevel(ModEnchantments.THUNDER_CALL.get(), stack);
        if (thunder > 0) BowEvents.callThunder(sl, impact, player, thunder);

        int cd = BowConfig.COOLDOWN_TICKS.get();
        if (cd > 0) player.getCooldowns().addCooldown(this, cd);
        stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(player.getUsedItemHand()));
        player.awardStat(net.minecraft.stats.Stats.ITEM_USED.get(this));
    }

    private static void stopChargeSound(Player player) {
        if (player instanceof ServerPlayer sp) {
            sp.connection.send(new ClientboundStopSoundPacket(SoundEvents.WARDEN_SONIC_CHARGE.getLocation(), SoundSource.PLAYERS));
        }
    }

    /** Raio Supersônico. Devolve o ponto final (impacto em bloco ou fim do alcance). */
    private static Vec3 fire(ServerLevel level, Player player, float damage) {
        Vec3 eye = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        double range = BowConfig.RANGE.get();
        Vec3 end = eye.add(dir.scale(range));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        boolean blocked = hit.getType() != HitResult.Type.MISS;
        if (blocked) end = hit.getLocation();
        final Vec3 finalEnd = end;

        // dano: cada criatura da linha leva o golpe uma única vez
        AABB box = new AABB(eye, finalEnd).inflate(1.5D);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box, t ->
                t != player && t.isAlive() && !(t instanceof ArmorStand) && !t.isAlliedTo(player)
                        && !(t instanceof TamableAnimal ta && ta.isOwnedBy(player))
                        && t.getBoundingBox().inflate(0.4D).clip(eye, finalEnd).isPresent());
        for (LivingEntity t : targets) {
            if (t.hurt(level.damageSources().sonicBoom(player), damage)) {
                double kb = 1.0D - t.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE);
                t.push(dir.x * 1.6D * kb, dir.y * 0.4D * kb + 0.1D * kb, dir.z * 1.6D * kb);
                level.sendParticles(ParticleTypes.SCULK_CHARGE_POP, t.getX(), t.getY(0.5D), t.getZ(), 6, 0.3D, 0.4D, 0.3D, 0.02D);
                level.playSound(null, t.getX(), t.getY(), t.getZ(), SoundEvents.WARDEN_ATTACK_IMPACT, SoundSource.PLAYERS, 1.0F, 1.0F);
            }
        }

        // feixe visual: linha fina ciano (faíscas curtas + poeira ciano/azul), saindo da frente da mão
        Vec3 start = eye.add(dir.scale(1.2D)).add(0.0D, -0.2D, 0.0D);
        double len = finalEnd.subtract(start).length();
        for (double d = 0.0D; d < len; d += 0.35D) {
            Vec3 p = start.add(dir.scale(d));
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            if (((int) (d / 0.35D)) % 2 == 0) {
                level.sendParticles(CYAN, p.x, p.y, p.z, 1, 0.03D, 0.03D, 0.03D, 0.0D);
            }
            if (((int) (d / 0.35D)) % 5 == 0) {
                level.sendParticles(DEEP, p.x, p.y, p.z, 2, 0.18D, 0.18D, 0.18D, 0.0D);
            }
            if (((int) (d / 0.35D)) % 22 == 0 && d > 1.0D) {
                level.sendParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
        // onda de choque no ponto final
        level.sendParticles(ParticleTypes.SONIC_BOOM, finalEnd.x, finalEnd.y, finalEnd.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        if (blocked) {
            level.sendParticles(ParticleTypes.SCULK_CHARGE_POP, finalEnd.x, finalEnd.y, finalEnd.z, 10, 0.3D, 0.3D, 0.3D, 0.05D);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 2.0F, 1.0F);
        return finalEnd;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("item.classselector.hyper_sculk_bow.lore1").withStyle(ChatFormatting.GRAY));
        tips.add(Component.translatable("item.classselector.hyper_sculk_bow.lore2").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        tips.add(Component.empty());
        tips.add(Component.translatable("item.classselector.hyper_sculk_bow.ability").withStyle(ChatFormatting.DARK_AQUA));
        tips.add(Component.translatable("item.classselector.hyper_sculk_bow.noammo").withStyle(ChatFormatting.DARK_AQUA));
        super.appendHoverText(stack, level, tips, flag);
    }
}
