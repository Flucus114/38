package com.classselector;

import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, ClassSelectorMod.MODID);

    public static final RegistryObject<MenuType<WardenMenu>> WARDEN_GEAR =
            MENUS.register("warden_gear", () -> IForgeMenuType.create(WardenMenu::new));
}
