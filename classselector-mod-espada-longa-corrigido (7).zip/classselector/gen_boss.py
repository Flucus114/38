import math, random, zlib, os
import numpy as np
from PIL import Image

OUT_J = '/home/claude/classselector/src/main/java/com/classselector/CosmicBossModel.java'
OUT_T = '/home/claude/classselector/src/main/resources/assets/classselector/textures/entity/'
TEX_W = 256
TORSO_UP = 63           # altura (px) do centro do torso; o fim do rabo fica em ~0

P = []
def part(name, parent, pivot, org, size, style, rot=(0,0,0), g=(0.0,1.0)):
    P.append(dict(name=name, parent=parent, pivot=pivot, org=org, size=size, style=style, rot=rot, g=g))
def O(w): return -w/2.0

# ---------------- torso, cabeça ----------------
part('torso', None, (0,24-TORSO_UP,0), (-12,-9,-6), (24,18,12), 'torso')
part('head', 'torso', (0,-17,0), (-7,-7,-7), (14,14,14), 'head')
part('collar', 'torso', (0,-9,0), (-8,-2,-6), (16,3,12), 'plate')
for S,sg in (('P',1),('N',-1)):
    part('trap'+S, 'torso', (sg*8,-9,0), (-4,-3,-5), (8,4,10), 'plate', (0,0,sg*0.32))

# chifres curvos (6 segmentos)
HW = [6,6,4,4,2,2]
HRZ = [0.35,0.2,0.2,0.05,-0.2,-0.2]
for S,sg in (('P',1),('N',-1)):
    prev='head'
    for k,w in enumerate(HW):
        piv = (sg*6,-6,0) if k==0 else (0,-3,0)
        nm='horn%s_%d'%(S,k)
        part(nm, prev, piv, (O(w),-3,O(w)), (w,3,w), 'horn', (0,0,sg*HRZ[k]), g=(k/6.0,(k+1)/6.0))
        prev=nm
part('crown', 'head', (0,-7,0), (-2,-12,-2), (4,12,4), 'crystal')

# peitoral e abdômen (malhado)
for S,sg in (('P',1),('N',-1)):
    part('pec'+S, 'torso', (sg*7,-4,-6), (-4,-3,-3), (8,7,3), 'plate')
for r in range(3):
    for c,cx in ((0,-2.5),(1,2.5)):
        part('ab%d_%d'%(r,c), 'torso', (cx,1+r*3.4,-6), (-2,-1.5,-2), (4,3,2), 'plate')

# ---------------- braços ----------------
FLEN = [(4,4,4),(5,5,4),(5,5,4),(5,5,4),(4,4,4)]
for S,sg in (('P',1),('N',-1)):
    part('shoulder'+S, 'torso', (sg*19,-5,0), (-6,-4,-6), (12,8,12), 'armor')
    part('cap'+S, 'shoulder'+S, (0,-4,0), (-7,-3,-7), (14,3,14), 'plate')
    for q in (0,1):
        x = sg*(3.5 if q==0 else -3.5)
        part('sps%s%d'%(S,q), 'cap'+S, (x,-3,0), (-1.5,-7,-1.5), (3,7,3), 'dark', (0,0,sg*(0.5 if q==0 else -0.2)), g=(0,1))
    part('arm'+S, 'shoulder'+S, (0,3,0), (-5,0,-5), (10,14,10), 'armor')
    part('bic'+S, 'arm'+S, (0,5,-5), (-4,-3,-3), (8,6,3), 'plate')
    part('fore'+S, 'arm'+S, (0,14,0), (-5,0,-5), (10,13,10), 'armor2')
    part('ringA'+S, 'fore'+S, (0,3,0), (-6,0,-6), (12,2,12), 'plate')
    part('ringB'+S, 'fore'+S, (0,10,0), (-6,0,-6), (12,3,12), 'plate')
    part('hand'+S, 'fore'+S, (0,13,0), (-4,0,-3), (8,5,6), 'armor')
    for k in range(5):
        prev='hand'+S
        for m in range(3):
            nm='f%s%d_%d'%(S,k,m)
            h=FLEN[k][m]
            if m==0:
                piv=((k-2)*1.7,5,0); rot=(-0.2,0,-(k-2)*0.3); size=(3,h,3); st='claw'
            elif m==1:
                piv=(0,FLEN[k][0],0); rot=(-0.35,0,0); size=(2,h,2); st='claw'
            else:
                piv=(0,FLEN[k][1],0); rot=(-0.35,0,0); size=(2,h,1); st='nail'
            part(nm, prev, piv, (O(size[0]),0,O(size[2])), size, st, rot, g=(m/3.0,(m+1)/3.0))
            prev=nm

# ---------------- espinhos nas costas (10, curvos) ----------------
SW = [4,4,2,2]; SH = [5,5,4,4]
SPK = [(9,-8,0.25),(12,-7,0.45),(15,-6,0.65),(18,-5,0.85),(20,-3,1.05)]
si = 0
for sg in (1,-1):
    for (x,y,zr) in SPK:
        prev='torso'
        for k in range(4):
            nm='sp%d_%d'%(si,k)
            if k==0: piv=(sg*x,y,6); rot=(-0.5,0,sg*zr)
            else:    piv=(0,-SH[k-1],0); rot=(-0.12,0,sg*0.14)
            w=SW[k]; h=SH[k]
            part(nm, prev, piv, (O(w),-h,O(w)), (w,h,w), 'spike', rot, g=(k/4.0,(k+1)/4.0))
            prev=nm
        si += 1

# ---------------- mochila ----------------
part('pack', 'torso', (0,0,6), (-7,-7,0), (14,14,8), 'pack')
part('podP', 'pack', (9,0,4), (-2,-6,-3), (4,12,6), 'plate')
part('podN', 'pack', (-9,0,4), (-2,-6,-3), (4,12,6), 'plate')
for i,x in enumerate((-5,0,5)):
    part('engine%d'%i, 'pack', (x,7,4), (-4,0,-4), (8,3,8), 'plate')
    part('eorb%d'%i, 'engine%d'%i, (0,6,0), (-3,-3,-3), (6,6,6), 'galaxy')

# ---------------- pélvis e rabo ----------------
part('pelvis', 'torso', (0,11,0), (-8,-3,-5), (16,6,10), 'plate')
part('orb', 'pelvis', (0,1,-7), (-5,-5,-5), (10,10,10), 'galaxy')
TW = [(12,8),(10,8),(8,6),(8,6),(6,4),(4,4),(4,2),(2,2)]
prev='pelvis'
for k,(w,d) in enumerate(TW):
    h = 7 if k==len(TW)-1 else 6
    nm='tail%d'%k
    part(nm, prev, (0,3 if k==0 else 6,0), (O(w),0,O(d)), (w,h,d), 'nebula', g=(k/8.0,(k+1)/8.0))
    prev=nm

# ---------------- empacotamento ----------------
def net(sz):
    w,h,d = sz
    return int(math.ceil(2*(w+d))), int(math.ceil(h+d))
order = sorted(P, key=lambda p: -net(p['size'])[1])
x=y=shelf=0
for p in order:
    nw,nh = net(p['size'])
    if x+nw > TEX_W:
        x=0; y+=shelf; shelf=0
    p['uv']=(x,y); x+=nw; shelf=max(shelf,nh)
used=y+shelf
TEX_H=64
while TEX_H<used: TEX_H*=2

# ---------------- pintura ----------------
rng = np.random.default_rng(7)
base = np.zeros((TEX_H,TEX_W,4),dtype=np.uint8)
glow = np.zeros((TEX_H,TEX_W,4),dtype=np.uint8); glow[...,3]=255
def clamp(c): return tuple(int(max(0,min(255,v))) for v in c)
def mix(a,b,t): return tuple(a[i]+(b[i]-a[i])*t for i in range(3))
def hsh(a,b,s=0): return ((int(a)*73856093) ^ (int(b)*19349663) ^ (s*83492791)) & 0xffff
def dim(c,f): return tuple(int(v*f) for v in c)

PURPLE=(140,90,255); LAV=(190,150,255); CYAN=(90,200,255); BLUE=(110,130,255); WHITE=(240,235,255)

def ramp(t, stops):
    t=max(0.0,min(1.0,t))
    for (t0,c0),(t1,c1) in zip(stops, stops[1:]):
        if t<=t1:
            f=(t-t0)/(t1-t0) if t1>t0 else 0
            return mix(c0,c1,f)
    return stops[-1][1]

CR=[(0,(80,50,210)),(0.4,(70,110,255)),(0.75,(130,230,255)),(1,(235,245,255))]
HR=[(0,(18,14,38)),(0.45,(60,45,130)),(0.8,(150,120,255)),(1,(235,230,255))]
SR=[(0,(14,10,30)),(0.5,(40,25,90)),(1,(160,95,255))]
TR=[(0,(70,30,150)),(0.3,(145,50,210)),(0.55,(60,85,235)),(0.8,(50,175,240)),(1,(140,238,255))]
OR=[(0,(240,250,255)),(0.25,(110,220,255)),(0.55,(80,100,240)),(1,(160,60,215))]
CL=[(0,(45,30,120)),(0.45,(110,100,250)),(0.8,(160,225,255)),(1,(225,245,255))]
NL=[(0,(150,200,255)),(1,(235,250,255))]

SHADE={'top':1.35,'front':1.0,'west':0.82,'east':0.82,'back':0.9,'bottom':0.6}

def gen_lines(fw,fh,rs):
    """riscos brilhantes tipo circuito/runas (andam em linha reta e viram 90 graus)"""
    mask={}
    if fw<4 or fh<4: return mask
    n=max(1,(fw*fh)//36)
    for _ in range(n):
        x=rs.randrange(fw); y=rs.randrange(fh)
        dx,dy=rs.choice([(1,0),(0,1),(-1,0),(0,-1)])
        col=rs.choice([PURPLE,PURPLE,BLUE,CYAN])
        for _s in range(rs.randrange(5,14)):
            if 0<=x<fw and 0<=y<fh: mask[(x,y)]=col
            if rs.random()<0.28:
                dx,dy=(dy,dx) if rs.random()<0.5 else (-dy,-dx)
            x+=dx; y+=dy
    return mask

def armor(face,fw,fh,i,j,lm):
    n=rng.random()
    b=mix((15,12,34),(26,20,54),n)
    nb=(hsh(i//3,j//3,9)%100)/100.0
    b=mix(b,(40,28,92),nb*0.25)
    if i==0 or j==0: b=mix(b,(78,62,130),0.5)
    if i==fw-1 or j==fh-1: b=mix(b,(6,5,14),0.5)
    f=SHADE[face]; b=tuple(v*f for v in b)
    g=None
    if (i,j) in lm:
        c=lm[(i,j)]; b=c; g=dim(c,0.85)
    return b,g

def paint(p, face, i, j, fw, fh, lm):
    st=p['style']
    g0,g1=p['g']
    if face=='top': tt=g0
    elif face=='bottom': tt=g1
    else: tt=g0+(g1-g0)*(j/max(1,fh-1))
    if st=='torso':
        if face=='front':
            cx,cy=11.5,8.5
            d=math.hypot(i-cx,j-cy)
            if d<5.2:
                if abs(d-4.3)<0.7: return LAV,LAV
                if abs(d-2.6)<0.5: return PURPLE,PURPLE
                if d<1.2: return WHITE,WHITE
                return (10,8,22),None
        return armor(face,fw,fh,i,j,lm)
    if st=='pack':
        if face=='back':
            cx,cy=(fw-1)/2,(fh-1)/2
            r=math.hypot(i-cx,j-cy); a=math.atan2(j-cy,i-cx)
            if r<6.4:
                if abs(r-6.0)<0.7: return PURPLE,PURPLE
                v=math.sin(a*2+r*0.9)
                c=mix((90,50,200),(120,220,255),(v+1)/2) if r>1.6 else WHITE
                return clamp(c),clamp(c)
        return armor(face,fw,fh,i,j,lm)
    if st=='head':
        if face=='front':
            # boca: buraco aberto
            if 2<=i<=11 and 9<=j<=13:
                if i in (2,11) or j in (9,13): return (80,50,170),(95,60,200)
                return (0,0,0),None
            ex,ey=6.5,4.0
            d=math.hypot(i-ex,(j-ey)*0.95)
            if abs(i-ex)<1.3 and abs(j-ey)<3.0: return (0,0,0),None       # pupila preta
            if d<3.0:
                c=clamp(mix((120,150,255),(190,150,255),d/3.0)); return c,c  # iris
            if d<4.0: return LAV,LAV
            if d<5.0: return PURPLE,PURPLE
            if d<5.8: return (5,4,10),None                                # órbita escura
        return armor(face,fw,fh,i,j,lm)
    if st in ('armor','plate'): return armor(face,fw,fh,i,j,lm)
    if st=='armor2':
        b,g=armor(face,fw,fh,i,j,lm)
        if face in('front','back') and 2<=i<=fw-3 and j%5==2: return PURPLE,dim(PURPLE,0.85)
        return b,g
    if st=='dark':
        b,g=armor(face,fw,fh,i,j,lm)
        return mix(b,(8,6,16),0.4),g
    if st=='spike':
        c=ramp(tt,SR)
        c=mix(c,(0,0,0),0.12*((hsh(i,j,11)%100)/100.0))
        gl=(0,0,0)
        if i==fw//2:                           # risco central brilhante
            c=mix(c,(170,110,255),0.5+0.5*tt); gl=dim(c,max(0.2,tt))
        return clamp(c),clamp(gl)
    if st=='horn':
        c=ramp(tt,HR)
        gl=mix((0,0,0),c,max(0.0,(tt-0.4)/0.6)**1.3)
        return clamp(c),clamp(gl)
    if st=='crystal':
        f=(hsh(i//2,j//3,3)%100)/100.0
        c=clamp(ramp(tt+(f-0.5)*0.18,CR)); return c,clamp(dim(c,0.9))
    if st=='claw':
        c=ramp(tt,CL)
        if i==fw//2: c=mix(c,(235,250,255),0.3)                  # faceta central
        c=clamp(c); return c,clamp(dim(c,0.5+0.5*tt))
    if st=='nail':
        c=clamp(ramp(j/max(1,fh-1),NL))
        if i==fw//2 and fw>1: c=clamp(mix(c,(255,255,255),0.4))
        return c,c
    if st=='galaxy':
        cx,cy=(fw-1)/2,(fh-1)/2
        R=max(cx,cy)+0.5
        r=math.hypot(i-cx,j-cy); a=math.atan2(j-cy,i-cx)
        t=r/R+0.18*math.sin(a*2+r*0.9)
        c=clamp(ramp(t,OR)); return c,c
    if st=='nebula':
        v=math.sin(i*0.9+j*0.55+hsh(i//2,j//2,6)%5)
        c=ramp(tt+0.04*v,TR)
        if v>0.55: c=mix(c,(215,95,235),0.35)
        if v<-0.7: c=mix(c,(20,15,70),0.35)
        if v>0.93: c=mix(c,(235,180,255),0.5)
        c=clamp(c); return c,clamp(dim(c,0.88))
    return (255,0,255),None

for p in P:
    u,v=p['uv']; w,h,d=p['size']
    W,H,D=int(math.ceil(w)),int(math.ceil(h)),int(math.ceil(d))
    faces={'top':(u+D,v,W,D),'bottom':(u+D+W,v,W,D),'west':(u,v+D,D,H),
           'front':(u+D,v+D,W,H),'east':(u+D+W,v+D,D,H),'back':(u+2*D+W,v+D,W,H)}
    for fn,(fx,fy,fw,fh) in faces.items():
        lm=gen_lines(fw,fh,random.Random(zlib.crc32((p['name']+fn).encode())))
        for j in range(fh):
            for i in range(fw):
                b,g=paint(p,fn,i,j,fw,fh,lm)
                base[fy+j,fx+i]=(*clamp(b),255)
                if g is not None: glow[fy+j,fx+i]=(*clamp(g),255)

os.makedirs(OUT_T,exist_ok=True)
Image.fromarray(base,'RGBA').save(OUT_T+'cosmic_sovereign.png')
Image.fromarray(glow,'RGBA').save(OUT_T+'cosmic_sovereign_glow.png')

# ---------------- java ----------------
def f(v):
    s=('%.3f'%v).rstrip('0').rstrip('.')
    return (s if s and s!='-' else '0')+'F'
lines=[]
for p in P:
    var=p['name']; par='root' if p['parent'] is None else p['parent']
    u,v=p['uv']; ox,oy,oz=p['org']; w,h,d=p['size']; px,py,pz=p['pivot']; rx,ry,rz=p['rot']
    lines.append('        PartDefinition %s = %s.addOrReplaceChild("%s", CubeListBuilder.create().texOffs(%d, %d).addBox(%s, %s, %s, %s, %s, %s), PartPose.offsetAndRotation(%s, %s, %s, %s, %s, %s));'
      %(var,par,var,u,v,f(ox),f(oy),f(oz),f(w),f(h),f(d),f(px),f(py),f(pz),f(rx),f(ry),f(rz)))
build='\n'.join(lines)

java = '''package com.classselector;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Modelo do Soberano Cósmico. GERADO por gen_boss.py (geometria + UVs da textura).
 * As animações ficam em setupAnim.
 */
public class CosmicBossModel extends EntityModel<CosmicBoss> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ClassSelectorMod.MODID, "cosmic_sovereign"), "main");
    private static final float RAD = (float) Math.PI / 180F;
    private static final float TORSO_Y = __TORSO_Y__F;
    private static final int SPIKES = 10, SPIKE_SEGS = 4, TAIL_SEGS = 8, FING_SEGS = 3;

    private final ModelPart root, torso, head, orb;
    private final ModelPart[] arm = new ModelPart[2], fore = new ModelPart[2], hand = new ModelPart[2];
    private final ModelPart[][][] fing = new ModelPart[2][5][FING_SEGS];
    private final float[][][] fingBaseX = new float[2][5][FING_SEGS], fingBaseZ = new float[2][5][FING_SEGS];
    private final ModelPart[][] spike = new ModelPart[SPIKES][SPIKE_SEGS];
    private final float[][] spikeBaseX = new float[SPIKES][SPIKE_SEGS], spikeBaseZ = new float[SPIKES][SPIKE_SEGS];
    private final ModelPart[] engineOrb = new ModelPart[3], tail = new ModelPart[TAIL_SEGS];

    public CosmicBossModel(ModelPart root) {
        this.root = root;
        this.torso = root.getChild("torso");
        this.head = torso.getChild("head");
        ModelPart pelvis = torso.getChild("pelvis");
        this.orb = pelvis.getChild("orb");
        String[] sides = {"P", "N"};
        for (int s = 0; s < 2; s++) {
            ModelPart sh = torso.getChild("shoulder" + sides[s]);
            arm[s] = sh.getChild("arm" + sides[s]);
            fore[s] = arm[s].getChild("fore" + sides[s]);
            hand[s] = fore[s].getChild("hand" + sides[s]);
            for (int k = 0; k < 5; k++) {
                ModelPart prev = hand[s];
                for (int m = 0; m < FING_SEGS; m++) {
                    fing[s][k][m] = prev.getChild("f" + sides[s] + k + "_" + m);
                    fingBaseX[s][k][m] = fing[s][k][m].xRot;
                    fingBaseZ[s][k][m] = fing[s][k][m].zRot;
                    prev = fing[s][k][m];
                }
            }
        }
        for (int i = 0; i < SPIKES; i++) {
            ModelPart prev = torso;
            for (int k = 0; k < SPIKE_SEGS; k++) {
                spike[i][k] = prev.getChild("sp" + i + "_" + k);
                spikeBaseX[i][k] = spike[i][k].xRot;
                spikeBaseZ[i][k] = spike[i][k].zRot;
                prev = spike[i][k];
            }
        }
        ModelPart pack = torso.getChild("pack");
        for (int i = 0; i < 3; i++) engineOrb[i] = pack.getChild("engine" + i).getChild("eorb" + i);
        ModelPart prev = pelvis;
        for (int i = 0; i < TAIL_SEGS; i++) { tail[i] = prev.getChild("tail" + i); prev = tail[i]; }
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
__BUILD__
        return LayerDefinition.create(mesh, __TW__, __TH__);
    }

    @Override
    public void setupAnim(CosmicBoss e, float limbSwing, float limbSwingAmount, float age, float yaw, float pitch) {
        float t = age;
        float[] w = e.getPoseWeights(); // 0 parado, 1 orbes, 2 pulso, 3 raio

        torso.y = TORSO_Y + Mth.sin(t * 0.09F) * 1.6F;
        torso.xRot = 0.05F + w[2] * -0.2F + w[3] * 0.1F;
        head.yRot = yaw * RAD * 0.7F;
        head.xRot = pitch * RAD * 0.7F;

        // parado: braço desce para o lado e o antebraço dobra PARA FRENTE, mãos abertas
        float armX = w[0] * -0.35F + w[1] * -1.2F + w[3] * -1.5F;
        float armZ = w[0] * (0.75F + Mth.sin(t * 0.08F) * 0.06F) + w[1] * 0.3F + w[2] * 2.7F + w[3] * 0.12F;
        float foreX = w[0] * -1.45F + w[1] * -0.5F + w[3] * -0.1F;
        float foreIn = w[0] * 0.15F;
        float open = 1.0F + 0.5F * (w[1] + w[3]) + 0.6F * w[2];
        for (int s = 0; s < 2; s++) {
            float sg = s == 0 ? -1.0F : 1.0F; // lado +x gira para fora com z negativo
            arm[s].xRot = armX;
            arm[s].zRot = sg * armZ;
            fore[s].xRot = foreX;
            fore[s].yRot = -sg * foreIn;
            hand[s].xRot = w[0] * -0.2F + w[1] * -0.1F;
            for (int k = 0; k < 5; k++) {
                for (int m = 0; m < FING_SEGS; m++) {
                    fing[s][k][m].xRot = fingBaseX[s][k][m] + Mth.sin(t * 0.12F + k + m * 0.5F) * 0.05F;
                    fing[s][k][m].zRot = fingBaseZ[s][k][m] * open;
                }
            }
        }

        for (int i = 0; i < TAIL_SEGS; i++) {
            tail[i].xRot = 0.06F + Mth.sin(t * 0.09F - i * 0.6F) * 0.10F;
            tail[i].yRot = Mth.sin(t * 0.07F - i * 0.7F) * 0.20F;
        }
        orb.yRot = t * 0.04F;
        orb.xRot = t * 0.025F;
        for (int i = 0; i < 3; i++) {
            engineOrb[i].yRot = t * 0.05F + i;
            engineOrb[i].xRot = t * 0.03F;
        }
        for (int i = 0; i < SPIKES; i++) {
            for (int k = 0; k < SPIKE_SEGS; k++) {
                float ph = t * 0.06F + i * 0.7F + k * 0.6F;
                spike[i][k].zRot = spikeBaseZ[i][k] + Mth.sin(ph) * 0.05F;
                spike[i][k].xRot = spikeBaseX[i][k] + Mth.cos(ph) * 0.03F;
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer buf, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, buf, light, overlay, r, g, b, a);
    }
}
'''
java = java.replace('__BUILD__',build).replace('__TW__',str(TEX_W)).replace('__TH__',str(TEX_H)).replace('__TORSO_Y__',str(24-TORSO_UP)+'.0')
open(OUT_J,'w',encoding='utf-8').write(java)
print('parts',len(P),'tex',TEX_W,TEX_H,'used',used)
